package com.utlities;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;

import com.knapsackObject.KnapsackData;
import com.knapsackObject.Problem;
import com.knapsackObject.Solution;


public class knapsackUtility {
    
    // A utility function that returns
    // maximum of two integers
    public int max(int a, int b)
    {
        return (a > b) ? a : b;
    }
 
    public static Object knapsackOptimizer(KnapsackData kp) throws IOException, JSONException
    {
    	//Initializing the time stamp
        kp.getTimeStamp().setSubmitted(getLocalTime());
        kp.setStatus("submitted");
        
        KnapsackData finalResult = new KnapsackData();
        finalResult.setId(kp.getId());
        finalResult.setProblem(kp.getProblem());
    	finalResult.getTimeStamp().setStarted(getLocalTime());
    	
    	Problem pb = (Problem)kp.getProblem();
    	int n = pb.getWeights().size();
    	int W = pb.getCapacity();
    	int wt[] = new int[n];
    	int val[] = new int[n];
    	
    	for(int j=0; j<n; j++) {
    		wt[j] = pb.getWeights().get(j);
    		val[j] = pb.getValues().get(j);	
    	}
    	
        int i, w;
        int K[][] = new int[n + 1][W + 1];
      
        // Build table K[][] in bottom up manner
        for (i = 0; i <= n; i++) {
            for (w = 0; w <= W; w++) {
                if (i == 0 || w == 0)
                    K[i][w] = 0;
                else if (wt[i - 1] <= w)
                    K[i][w] = Math.max(val[i - 1] +
                              K[i - 1][w - wt[i - 1]], K[i - 1][w]);
                else
                    K[i][w] = K[i - 1][w];
            }
        }
 
        // stores the result of Knapsack
        int res = K[n][W];
        
        Solution sol = new Solution();
        if(res == 0) {
        	
        }
        sol.setTotal_value(res);
        
        //weight
        w = W;
        for (i = n; i > 0 && res > 0; i--) {
 
            if (res == K[i - 1][w])
                continue;
            else {	
               // sol.setw(wt[i - 1]);
                sol.setPacked_item(i-1);
                res = res - val[i - 1];
                w = w - wt[i - 1];
            }
        }
        finalResult.setStatus("completed");
        finalResult.setSolution(sol);
        finalResult.getTimeStamp().setCompleted(getLocalTime());
        
        //Storing the solution in a file into a single line
        String fileStr = "C:\\Users\\gravigop\\Desktop\\Eclipse\\knapsack\\src\\main\\java\\com\\utlities\\output.json"; 
        BufferedWriter out = new BufferedWriter(new FileWriter(fileStr, true));
        out.write(finalResult.toString());
        out.close();
        
        return kp;
    }
    
    
    public static String getResult(String id) throws IOException, JSONException {
    	
    	String result = "No Data found";
    	 try {
    		 //File Location
    		 String fileStr = "C:\\Users\\gravigop\\Desktop\\Eclipse\\knapsack\\src\\main\\java\\com\\utlities\\output.json" ;
    	        // FileReader reads text files in the default encoding.
    	        FileReader fileReader = new FileReader(fileStr);
    	        BufferedReader bufferedReader = new BufferedReader(fileReader);
    	        String line;
    	        JSONObject obj;
    	        
    	        while((line = bufferedReader.readLine()) != null) {
    	        	obj = new JSONObject(line);
    	        	if(obj.getString("id").equals(id)) {
    	        		result = obj.toString();
    	        		break;
    	        	}
    	        	
    	        }
    	        bufferedReader.close();         
    	    }
    	    catch(FileNotFoundException ex) {
    	        System.out.println("Unable to open file  ");                
    	    }
    	return result;
    }
    
    
    private static String getLocalTime() {
    	return java.time.LocalDateTime.now().toString();  
        
    }
}