package com.knapsackObject;

import java.util.ArrayList;

import javax.json.bind.annotation.JsonbProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Problem {
	
	private int capacity;
	private ArrayList<Integer> weights = new ArrayList<Integer>();
	private ArrayList<Integer> values = new ArrayList<Integer>();
	
	
	@XmlElement
	@JsonbProperty(value="capacity")
	public int getCapacity() {
		return this.capacity;
	}
	
	public void setw(int wt) {
		this.weights.add(wt);
	}

	public void seti(int in) {
		this.values.add(in);
	}
	
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	@XmlElementWrapper(name="weights")
	@XmlElement(name="weight")
	@JsonbProperty(value="weights")
	public ArrayList<Integer> getWeights() {
		return weights;
	}
	public void setWeights(ArrayList<Integer> weights) {
		this.weights = weights;
	}
	
	@XmlElementWrapper(name="values")
	@XmlElement(name="index")
	@JsonbProperty(value="values")
	public ArrayList<Integer> getValues() {
		return values;
	}
	public void setValues(ArrayList<Integer> values) {
		this.values = values;
	}
	
	@Override
	public String toString() {
		String op = "\"problem\":";
			   op += "{\"capacity\":" + this.getCapacity() + ",";
			   op += "\"weights\": [" ;
			   for(int i=0; i< this.getWeights().size();i++) {
				   op += this.getWeights().get(i);
				   if(i != this.getWeights().size() -1 ) {
					   op += ",";
				   }else {
					   op += "]";
				   }
			   }
			   op += ",";
			   op += "\"values\": [" ;
			   for(int i=0; i< this.getValues().size();i++) {
				   op += this.getValues().get(i);
				   if(i != this.getValues().size() -1 ) {
					   op += ",";
				   }else {
					   op += "]}";
				   }
			   }
				
		return op;
	}
	
}
