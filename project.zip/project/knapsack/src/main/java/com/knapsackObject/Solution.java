package com.knapsackObject;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Solution {

	private int total_value;
	private ArrayList<Integer> packed_items = new ArrayList<Integer>();
	
	public int getTotal_value() {
		return total_value;
	}
	public void setTotal_value(int total_value) {
		this.total_value = total_value;
	}
	public ArrayList<Integer> getPacked_items() {
		return packed_items;
	}
	public void setPacked_items(ArrayList<Integer> packed_items) {
		this.packed_items = packed_items;
	}
	
	public void setPacked_item(int val) {
		this.packed_items.add(val);
	}
	
	@Override
	public String toString() {
		
		String op = "\"solution\":";
		       if(this.getTotal_value() == 0) {
		    	   op += "\"No solution found\"";
		       }else {
		    	   op += "{\"total_value\":" + this.getTotal_value() + ",";
				   op += "\"packed_items\": [" ;
				   for(int i=0; i< this.getPacked_items().size();i++) {
					   op += this.getPacked_items().get(i);
					   if(i != this.getPacked_items().size() -1 ) {
						   op += ",";
					   }else {
						   op += "]}";
					   }
				   }
		       }
			   
			  return op;
	}
	
	
}
