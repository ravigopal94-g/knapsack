package com.knapsackObject;

import javax.xml.bind.annotation.XmlRootElement;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;


@XmlRootElement
@JsonIgnoreProperties(ignoreUnknown = false)
public class KnapsackData {

	private String id;
	private String status;
	private Solution solution = new Solution();
	private Problem problem = new Problem();
	private TimeStamps timeStamp = new TimeStamps(); 
	
	public Problem getProblem() {
		return this.problem;
	}

	public TimeStamps getTimeStamp() {
		return this.timeStamp;
	}

	public void setTimeStamp(TimeStamps timeStamp) {
		this.timeStamp = timeStamp;
	}

	public void setProblem(Problem problem) {
		this.problem = problem;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Solution getSolution() {
		return this.solution;
	}

	public void setSolution(Solution solution) {
		this.solution = solution;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public KnapsackData(String id, Solution solution, Problem problem, String status) {
		this.id = id;
		this.status = status;
		this.solution = solution;
		this.problem = problem;
	}
	
	public KnapsackData() {
		
	}
	
	@Override
	public String toString() {
		
		String op = "{\"id\":" + "\"" + this.id + "\"," ;
			   op += "\"status\":" + "\"" + this.status + "\"," ;
			   op += this.getProblem().toString() + ",";
			   op += this.getSolution().toString() +",";
			   op += this.timeStamp;
			   op += "}\n";
		return op;
	}

}
