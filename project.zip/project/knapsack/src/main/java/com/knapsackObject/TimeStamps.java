package com.knapsackObject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class TimeStamps {
	
	private String submitted;
	private String started;
	private String completed;
	
	public String getSubmitted() {
		return submitted;
	}
	public void setSubmitted(String submitted) {
		this.submitted = submitted;
	}
	public String getStarted() {
		return started;
	}
	public void setStarted(String started) {
		this.started = started;
	}
	public String getCompleted() {
		return completed;
	}
	public void setCompleted(String completed) {
		this.completed = completed;
	}

	@Override
	public String toString() {
	
		String op = "\"timestamps\": {" ;
		   op += "\"submitted\":" +  "\"" + this.getStarted() + "\",";
		   op += "\"started\":" + "\"" + this.getStarted() + "\",";
		   op += "\"completed\": " + "\"" + this.getStarted() + "\"}";
		   
		  return op;
	}
}
