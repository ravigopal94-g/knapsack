package com.knapsack;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.PathParam;

import java.io.IOException;
import javax.ws.rs.Consumes;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONException;

import com.knapsackObject.KnapsackData;
import com.utlities.knapsackUtility;

 
@Path("/")
public class knapsack{
	
	
	 @GET
     @Path("/{id}")
     @Produces(MediaType.TEXT_PLAIN)
      public Response getCall(@PathParam("id") String id) throws IOException, JSONException {
	
		 String result = knapsackUtility.getResult(id);
		 if(result == "No Data found" ) {
			 return Response.status(500).entity(result).build();
		 }
		 return Response.status(200).entity(knapsackUtility.getResult(id)).build();
        
      }
	 
	   @POST
	   @Consumes(MediaType.APPLICATION_JSON)
	   @Produces(MediaType.APPLICATION_JSON)
	   public Object test(KnapsackData kp) throws IOException, JSONException  {
		   
		   if(kp.getId() == null || kp.getProblem() == null || kp.getId().isEmpty()) {
			   return Response.status(500).entity("Please check the inputs of setName or Problem").build();
		   }
		   else if(kp.getProblem().getValues().size() != kp.getProblem().getWeights().size() ) {
			   return Response.status(500).entity("Please check the weights and indexes").build();			   
		   }else if(kp.getProblem().getValues().size() == 0 || kp.getProblem().getWeights().size() == 0) {
			   return Response.status(500).entity("Please check the weights and indexes").build();
		   }
		   
		   return Response.status(200).entity(knapsackUtility.knapsackOptimizer(kp)).build();
	   }
}
 
